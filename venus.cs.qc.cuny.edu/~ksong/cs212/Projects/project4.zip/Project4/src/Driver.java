import java.io.*;
import java.util.*;

public class Driver {
	public static void main(String[] args) throws IOException {
		GoFish game = new GoFish();
		game.playGame();
	}
}